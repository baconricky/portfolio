Imports StoreFront.SystemBase
Imports StoreFront.BusinessRule
Imports StoreFront.BusinessRule.Management
Imports StoreFrontSecurity

'BEGINVERSIONINFO

'APPVERSION: 6.0.0.0

'STARTCOPYRIGHT
'The contents of this file are protected under the United States
'copyright laws and is confidential and proprietary to
'LaGarde, Incorporated.  Its use or disclosure in whole or in part without the
'expressed written permission of LaGarde, Incorporated is expressly prohibited.
'
'(c) Copyright 2002 by LaGarde, Incorporated.  All rights reserved.
'ENDCOPYRIGHT

'ENDVERSIONINFO

Public Class Encryption
    Inherits CWebPage
    Protected WithEvents PageTable As System.Web.UI.HtmlControls.HtmlTable
    Protected WithEvents ErrorMessage As System.Web.UI.WebControls.Label
    Protected WithEvents ErrorAlignment As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents filename As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents pnlKeyOptions As System.Web.UI.WebControls.Panel
    Protected WithEvents pnlDownloadKey As System.Web.UI.WebControls.Panel
    Protected WithEvents rbNewKey As System.Web.UI.WebControls.RadioButton
    Protected WithEvents rbReplaceKey As System.Web.UI.WebControls.RadioButton
    Protected WithEvents chkconfirm As System.Web.UI.WebControls.CheckBox
    Protected WithEvents lnkdownloadkey As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lnkSubmit As System.Web.UI.WebControls.LinkButton
    Protected WithEvents PageSubTable As System.Web.UI.HtmlControls.HtmlTable
    Private Const OPTIONKEY = "option"
    Protected WithEvents pnlUploadKey As System.Web.UI.WebControls.Panel
    Protected WithEvents txtKey As System.Web.UI.WebControls.TextBox
    Protected WithEvents lnkConfirmKey As System.Web.UI.WebControls.LinkButton
    Private Const OLDPRIVATEKEY = "downloadedfile"
    Private Const NEWPRIVATEKEY = "privatekey"
    Protected WithEvents lnkCancel As System.Web.UI.WebControls.LinkButton
    Private Const NEWPUBLICKEY = "publickey"


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            'Put user code to initialize the page here
            CType(Me.LeftColumnNav1.FindControl("CMenuBar1"), CMenubar).IsAdminArea = True
            rbReplaceKey.Enabled = StoreFrontConfiguration.ConvertedFrom3DES
            pnlUploadKey.Visible = StoreFrontConfiguration.ConvertedFrom3DES
            ErrorMessage.Visible = False
        Catch ex As Exception
            Session("DetailError") = "Class PaymentMethods Error=" & ex.Message
            Response.Redirect(StoreFrontConfiguration.SiteURL & "errors.aspx")
        End Try
    End Sub

    Private Sub lnkSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkSubmit.Click
        If Not ValidateAndSetOptions() Then Return
        EnableDownloadKeyPanel()
        pnlKeyOptions.Visible = False
    End Sub
    Private Function ValidateAndSetOptions() As Boolean

        If Not chkconfirm.Checked Then
            ErrorMessage.Visible = True
            ErrorMessage.Text = " Please Check the confirmation box to continue. "
            Return False
        End If

        If rbNewKey.Checked Then
            viewstate("option") = "new"
            SetNewKeys()
            Return True
        End If

        If rbReplaceKey.Enabled And rbReplaceKey.Checked Then
            If Not filename.PostedFile Is Nothing AndAlso filename.PostedFile.ContentLength > 0 Then
                viewstate(OPTIONKEY) = "replace"
                Dim myfBuffer(filename.PostedFile.ContentLength) As Byte
                filename.PostedFile.InputStream.Read(myfBuffer, 0, filename.PostedFile.ContentLength)
                Session(Me.OLDPRIVATEKEY) = System.Text.UTF8Encoding.UTF8.GetString(myfBuffer)
                SetNewKeys()
                Return True
            Else
                ErrorMessage.Visible = True
                ErrorMessage.Text = " Previous Key is required to Replace the Existing Key"
                Return False
            End If
        End If


            ErrorMessage.Visible = True
            ErrorMessage.Text = " Please select one option !"
        Return False
    End Function
    Private Sub lnkdownloadkey_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkdownloadkey.Click
        Try
            Dim myPrivateKey As String = Session(Me.NEWPRIVATEKEY)
            Response.AppendHeader("Content-Disposition", "attachment; filename=store.key")
            Response.ContentType = "text"
            Response.Write(myPrivateKey)
            Response.Flush()
            Response.End()
        Catch ex As Exception When Not TypeOf ex Is Threading.ThreadAbortException
            ErrorMessage.Visible = True
            ErrorMessage.Text = " Failed To Generate New Key : " & ex.Message
        End Try
    End Sub
    Private Sub RefreshConfiguration()
        Try
            'Dim mUser As String = Request.ServerVariables("AUTH_USER")
            'Dim mPAss As String = Request.ServerVariables("AUTH_PASSWORD")
            'Dim myRequest As System.Net.HttpWebRequest = System.Net.HttpWebRequest.Create(StoreFrontConfiguration.SiteURL & "ReloadXml.aspx?ssl=1")
            'myRequest.Credentials = New System.Net.NetworkCredential(mUser, mPAss)

            '    Dim myResponse As System.Net.HttpWebResponse = myRequest.GetResponse
            '    Dim aBuffer() As Byte
            '    aBuffer = New Byte(myResponse.ContentLength - 1) {}
            '    myResponse.GetResponseStream.Read(aBuffer, 0, myResponse.ContentLength)
            Dim objWeb As New BusinessRule.WebRequest.CWebRequest
            objWeb.Type = 1
            objWeb.URI = New String(StoreFrontConfiguration.SSLPath() & "ReloadXML.aspx?SSL=0")
            objWeb.SendRequest2(Request.ServerVariables("AUTH_USER"), Request.ServerVariables("AUTH_PASSWORD"))
            Catch ex As Exception
                ErrorMessage.Visible = True
                ErrorMessage.Text = " Failed to Reload XML. " & ex.Message
            End Try
    End Sub
    Private Sub SetNewKeys()
        Dim myCrypto As New StoreFrontRSACrypto
        myCrypto.GenerateKeyPair()
        Session(Me.NEWPRIVATEKEY) = myCrypto.RSAPrivateKey
        Session(Me.NEWPUBLICKEY) = myCrypto.RSAPublicKey
    End Sub
    Private Sub lnkConfirmKey_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkConfirmKey.Click
        Dim mykeyManage As New SecurityKeyManagement
        Dim myPrivateKey As String = Session(Me.NEWPRIVATEKEY)
        Dim myPublickey As String = Session(Me.NEWPUBLICKEY)
        Dim myOldPrivatekey As String = Session(Me.OLDPRIVATEKEY)

        If viewstate(OPTIONKEY) = "replace" Then
            Try
                myPrivateKey = mykeyManage.ReplaceKeyPair(Session(Me.OLDPRIVATEKEY), myPublickey)
            Catch ex As Exception
                SetReplaceKeyError(ex)
                Return
            End Try
        ElseIf viewstate(OPTIONKEY) = "new" Then
            Try
                myPrivateKey = mykeyManage.SetNewPrivateKey(myPublickey)
            Catch ex As Exception
                SetNewKeyError(ex)
                Return
            End Try
        End If
        RefreshConfiguration()
        SetOptionsPanel()
        If Not ErrorMessage.Visible Then
            ErrorMessage.Visible = True
            ErrorMessage.Text = "Successfully Converted Data"
        End If


        'Session.Remove(Me.NEWPRIVATEKEY)
        'Session.Remove(Me.NEWPUBLICKEY)
        'Session.Remove(Me.OLDPRIVATEKEY)
        'viewstate.Remove(Me.OPTIONKEY)
        ''this would redirect and remove the old viewstate
        'Response.Redirect("Encryption.aspx?", True)
    End Sub
    Private Sub EnableDownloadKeyPanel()
        pnlDownloadKey.Visible = True
        txtKey.Text = Session(Me.NEWPRIVATEKEY)
    End Sub
    Private Sub SetOptionsPanel()
        pnlDownloadKey.Visible = False
        pnlKeyOptions.Visible = True
        rbReplaceKey.Enabled = StoreFrontConfiguration.ConvertedFrom3DES
        pnlUploadKey.Visible = StoreFrontConfiguration.ConvertedFrom3DES
        txtKey.Text = String.Empty
        Session.Remove(Me.NEWPRIVATEKEY)
        Session.Remove(Me.NEWPUBLICKEY)
        Session.Remove(Me.OLDPRIVATEKEY)
        viewstate.Remove(Me.OPTIONKEY)
    End Sub
    Private Sub SetNewKeyError(ByVal ex As Exception)
        SetOptionsPanel()
        ErrorMessage.Visible = True
        ErrorMessage.Text = "Failed to Convert data for new Key " & ex.Message
    End Sub
    Private Sub SetReplaceKeyError(ByVal ex As Exception)
        SetOptionsPanel()
        ErrorMessage.Visible = True
        ErrorMessage.Text = "Failed to Convert data for Replaced Key " & ex.Message
    End Sub
    Private Sub lnkCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkCancel.Click
        SetOptionsPanel()
    End Sub
End Class
